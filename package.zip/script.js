// ========================================
// Image Protection System
// ========================================

// Disable right-click on images
document.addEventListener('contextmenu', function(e) {
    if (e.target.tagName === 'IMG' || e.target.closest('.image-container')) {
        e.preventDefault();
        showProtectionMessage();
        return false;
    }
});

// Prevent drag and drop on images
document.addEventListener('dragstart', function(e) {
    if (e.target.tagName === 'IMG') {
        e.preventDefault();
        return false;
    }
});

// Disable keyboard shortcuts for saving images
document.addEventListener('keydown', function(e) {
    // Ctrl+S or Cmd+S
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        showProtectionMessage();
        return false;
    }
    
    // Ctrl+Shift+I or Cmd+Opt+I (DevTools)
    if ((e.ctrlKey && e.shiftKey && e.key === 'I') || 
        (e.metaKey && e.altKey && e.key === 'i')) {
        e.preventDefault();
        return false;
    }
    
    // F12 (DevTools)
    if (e.key === 'F12') {
        e.preventDefault();
        return false;
    }
});

// Show protection message
function showProtectionMessage() {
    const existingMessage = document.querySelector('.protection-message');
    if (existingMessage) return;
    
    const message = document.createElement('div');
    message.className = 'protection-message';
    message.textContent = '🔒 Le immagini sono protette da copyright';
    message.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: linear-gradient(135deg, #8A2BE2, #6A1EAE);
        color: white;
        padding: 16px 24px;
        border-radius: 8px;
        z-index: 10000;
        font-family: 'Inter', sans-serif;
        font-size: 14px;
        font-weight: 500;
        box-shadow: 0 4px 20px rgba(138, 43, 226, 0.3);
        animation: slideInRight 300ms ease-out;
    `;
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.style.animation = 'slideOutRight 300ms ease-in';
        setTimeout(() => message.remove(), 300);
    }, 2500);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ========================================
// Mobile Navigation
// ========================================

const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const navMenu = document.querySelector('.nav-menu');

if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
        
        // Animate hamburger icon
        const spans = this.querySelectorAll('span');
        if (navMenu.classList.contains('active')) {
            spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
            spans[1].style.opacity = '0';
            spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
        } else {
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });
}

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll('.nav-link');
navLinks.forEach(link => {
    link.addEventListener('click', function() {
        if (window.innerWidth <= 768) {
            navMenu.classList.remove('active');
            const spans = mobileMenuToggle.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });
});

// ========================================
// Smooth Scrolling
// ========================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const navbarHeight = document.querySelector('.navbar').offsetHeight;
            const targetPosition = target.offsetTop - navbarHeight;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ========================================
// Active Navigation Link
// ========================================

function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navbarHeight = document.querySelector('.navbar').offsetHeight;
    
    let currentSection = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - navbarHeight - 100;
        const sectionHeight = section.offsetHeight;
        
        if (window.pageYOffset >= sectionTop && 
            window.pageYOffset < sectionTop + sectionHeight) {
            currentSection = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentSection}`) {
            link.classList.add('active');
        }
    });
}

window.addEventListener('scroll', updateActiveNavLink);

// ========================================
// Contact Form Handler
// ========================================

const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value
        };
        
        // Validate form
        if (!validateForm(formData)) {
            showFormMessage('error', 'Per favore compila tutti i campi correttamente.');
            return;
        }
        
        // Disable submit button
        const submitBtn = contactForm.querySelector('.btn-submit');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Invio in corso...';
        
        // Simulate form submission (replace with actual API call)
        setTimeout(() => {
            // Success
            showFormMessage('success', 'Messaggio inviato con successo! Ti risponderò al più presto.');
            contactForm.reset();
            submitBtn.disabled = false;
            submitBtn.textContent = 'Invia Messaggio';
            
            // Here you would typically send the data to a server
            console.log('Form submitted:', formData);
            
        }, 1500);
    });
}

function validateForm(data) {
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!data.name || data.name.trim().length < 2) return false;
    if (!emailRegex.test(data.email)) return false;
    if (!data.subject || data.subject.trim().length < 3) return false;
    if (!data.message || data.message.trim().length < 10) return false;
    
    return true;
}

function showFormMessage(type, message) {
    formMessage.className = `form-message ${type}`;
    formMessage.textContent = message;
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        formMessage.style.display = 'none';
    }, 5000);
}

// ========================================
// Gallery Item Click Handler
// ========================================

const galleryItems = document.querySelectorAll('.gallery-item');

galleryItems.forEach(item => {
    item.addEventListener('click', function() {
        const artId = this.getAttribute('data-art-id');
        const artTitle = this.querySelector('.artwork-title').textContent;
        
        // Show modal or detailed view (you can expand this)
        console.log(`Clicked on artwork: ${artTitle} (ID: ${artId})`);
        
        // You could open a modal here with more details about the artwork
        // For now, we'll just show a message
        showProtectionMessage();
    });
});

// ========================================
// Scroll Animations
// ========================================

function animateOnScroll() {
    const elements = document.querySelectorAll('.gallery-item, .about-content, .contact-container');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    elements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(element);
    });
}

// Initialize scroll animations when page loads
window.addEventListener('load', animateOnScroll);

// ========================================
// Additional Image Protection
// ========================================

// Prevent PrintScreen
document.addEventListener('keyup', function(e) {
    if (e.key === 'PrintScreen') {
        navigator.clipboard.writeText('');
        showProtectionMessage();
    }
});

// Blur page when user tries to screenshot (on supported browsers)
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // User switched tabs or minimized - potential screenshot
        console.log('Page visibility changed');
    }
});

// Watermark refresh on window focus
window.addEventListener('focus', function() {
    const watermarks = document.querySelectorAll('.watermark-overlay');
    watermarks.forEach(w => {
        w.style.display = 'flex';
    });
});

// ========================================
// Performance: Lazy Loading Images
// ========================================

if ('loading' in HTMLImageElement.prototype) {
    const images = document.querySelectorAll('img[loading="lazy"]');
    images.forEach(img => {
        img.src = img.dataset.src;
    });
} else {
    // Fallback for browsers that don't support lazy loading
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js';
    document.body.appendChild(script);
}

// ========================================
// Console Warning
// ========================================

console.log('%c⚠️ ATTENZIONE', 'color: #EF4444; font-size: 24px; font-weight: bold;');
console.log('%cQuesto sito e tutte le immagini sono protetti da copyright.', 'color: #8A2BE2; font-size: 16px;');
console.log('%c© DigitalArtRaymond - Tutti i diritti riservati', 'color: #A1A1AA; font-size: 14px;');

// ========================================
// Initialize
// ========================================

console.log('✅ DigitalArtRaymond Portfolio caricato con successo');
console.log('🔒 Sistema di protezione immagini attivo');
